import cv2 as cv

img_watermarked = cv.imread('Images/Watermarked.jpg')
cv.imshow('Watermarked Image', img_watermarked)